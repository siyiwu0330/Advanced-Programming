-module(async).

-export([new/2, wait/1, poll/1]).

new(Fun, Arg) -> nope.
wait(Aid) -> nope.
poll(Aid) -> nope.

