-module(rps).
-export([start/0, queue_up/3, move/2, statistics/1, drain/3]).

start() -> nope.

queue_up(_, _, _) -> nope.

move(_, _) -> nope.

statistics(_) -> nope.

drain(_, _, _) ->  nope.
