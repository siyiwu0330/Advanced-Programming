-module(async).

-export([new/2, wait/1, poll/1, wait_catch/1, wait_any/1]).

new(Fun, Arg) -> nope.
wait(Aid) -> nope.
poll(Aid) -> nope.
wait_catch(Aid) -> nope.
wait_any(Aids) -> nope.
